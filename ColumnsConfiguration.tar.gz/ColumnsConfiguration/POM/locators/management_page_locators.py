from selenium.webdriver.common.by import By


def getMenuLocatorXpath(title):
    return "//span[@class='ui-menuitem-text'][text()='" + title + "']"


def getSpanButtonLocatorXpath(title):
    return "//span[contains(@class,'ui-button-text')][text()='" + title + "']"


def getMenuButtonLocatorXpath(title):
    return "//div[@class='ui-menuitem-text'][text()='" + title + "']"


def getTextboxLocatorXpath(title):
    return "//input[@formcontrolname='" + title + "']"


class ManagementPageLocators:

    # Management - Login Page
    username_textbox_name = (By.NAME, "loginname")
    password_textbox_name = (By.NAME, "password")
    login_button_xpath = (By.XPATH, "//div/button[contains(@type,'button')and contains(text(),'Log In')]")

    # Management - Login table rows
    active_devices_table_exit_row_xpath = (By.XPATH, "//*[@id='spark_deviceinfo']/p-table/div/div/table/tbody/tr[1]")
    active_devices_table_entry_row_xpath = (By.XPATH, "//*[@id='spark_deviceinfo']/p-table/div/div/table/tbody/tr[2]")

    # Management - Menus
    home_menu_xpath = (By.XPATH, getMenuLocatorXpath('Home'))
    operations_menu_xpath = (By.XPATH, getMenuLocatorXpath('Operations'))
    pos_menu_xpath = (By.XPATH, getMenuLocatorXpath('POS'))
    reporting_menu_xpath = (By.XPATH, getMenuLocatorXpath('Reporting'))
    season_parker_configuration_menu_xpath = (By.XPATH, getMenuLocatorXpath('Season Parker Configuration'))
    paid_parker_configuration_menu_xpath = (By.XPATH, getMenuLocatorXpath('Paid Parker Configuration'))
    facility_configuration_menu_xpath = (By.XPATH, getMenuLocatorXpath('Facility Configuration'))
    system_configuration_menu_xpath = (By.XPATH, getMenuLocatorXpath('System Configuration'))

    # Management - System Configuration > Submenus
    system_services_submenu_xpath = (By.XPATH, getMenuLocatorXpath('System Services'))
    system_keys_submenu_xpath = (By.XPATH, getMenuLocatorXpath('System Keys'))
    medium_management_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Medium Management'))
    open_interface_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Open Interface'))
    # reporting_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Reporting'))
    user_configuration_submenu_xpath = (By.XPATH, getMenuLocatorXpath('User Configuration'))

    # Management - System Configuration > System services
    system_update_nodelist_from_meshnodes_button_xpath = (By.XPATH, getMenuButtonLocatorXpath('Update Nodelist From Meshnodes'))

    # Management - System Configuration > User configuration > Submenus
    roles_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Roles'))
    users_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Users'))
    permissions_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Permissions'))
    user_reports_submenu_xpath = (By.XPATH, getMenuLocatorXpath('User Reports'))

    # Management - Facility Configuration > Submenus
    parking_facility_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Parking Facility'))
    parking_buildings_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Parking Buildings'))
    zones_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Zones'))
    lane_devices_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Lane Devices'))
    access_plans_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Access Plans'))
    counters_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Counters'))
    fire_alarm_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Fire Alarm'))

    # Management - Facility Configuration > Zones > Buttons
    lane_entry_edit_button_xpath = (By.XPATH, "(//span[@class='ui-button-icon-left ui-clickable ch-icon-edit'])[1]")
    lane_exit_edit_button_xpath = (By.XPATH, "(//span[@class='ui-button-icon-left ui-clickable ch-icon-edit'])[2]")

    # Management - Facility Configuration > Zones > Edit > Dropdown
    zone_from_dropdown_button_xpath = (By.XPATH, "(//div[@class='ui-dropdown-trigger ui-state-default ui-corner-right'])[2]")
    zone_to_dropdown_button_xpath = (By.XPATH, "(//div[@class='ui-dropdown-trigger ui-state-default ui-corner-right'])[3]")

    # Management - Facility Configuration > Zones > Edit > Dropdown > Options
    dropdown_option_outside_xpath = (By.XPATH, "//span[@class='ng-star-inserted'][text()='Parkingbuilding1.Parkinglevel1.outside']")
    dropdown_option_shorttermzone_xpath = (By.XPATH, "//span[@class='ng-star-inserted'][text()='Parkingbuilding1.Parkinglevel1.shorttermzone']")
    dropdown_option_contractzone_xpath = (By.XPATH, "//span[@class='ng-star-inserted'][text()='Parkingbuilding1.Parkinglevel1.contractzone']")

    # Management - Facility Configuration > Lane Devices
    edit_node_button_xpath = (By.XPATH, getMenuButtonLocatorXpath('Edit Node'))
    entry_device_td_text_xpath = (By.XPATH, "//td[contains(text(),'entry@')]")
    exit_device_td_text_xpath = (By.XPATH, "//td[contains(text(),'exit@')]")

    # Management - Facility Configuration > Lane Devices > Entry Node
    button_enabled_checkbox_xpath = (By.XPATH, "//p-checkbox[contains(@formcontrolname,'laneticketButtonEnabled')]/div/div/span[@class='ui-chkbox-icon ui-clickable']")
    enable_lpr_checkbox_xpath = (By.XPATH, "//p-checkbox[contains(@formcontrolname,'cameraenableLpr')]/div/div/span[@class='ui-chkbox-icon ui-clickable']")

    # Management - Facility Configuration > Lane Devices > Exit Node
    reader_enabled_checkbox_xpath = (By.XPATH, "//p-checkbox[contains(@formcontrolname,'laneticketReaderEnabled')]/div/div/span[@class='ui-chkbox-icon ui-clickable']")

    # Management - Facility Configuration > Lane Devices > Entry and Exit
    camera_user_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('camerauser'))
    camera_password_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('camerapassword'))
    camera_password_verification_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('camerapassword_verification'))
    friendly_name_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('nodefriendlyName'))
    display_url_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('lanedisplayUrl'))

    # Management - Facility Configuration > Access Plan
    new_access_plan_button_xpath = (By.XPATH, getMenuButtonLocatorXpath('New Access Plan'))

    # Management - Facility Configuration > Access Plan > New Access Plan
    access_plan_name_textbox_xpath = (By.XPATH, getTextboxLocatorXpath('accessplaname'))

    # Management - Facility Configuration > Access Plan > New Access Plan > Dropdowns
    entry_access_plan_details_dropdown_id = (By.ID, "ui-accordiontab-0")
    exit_access_plan_details_dropdown_id = (By.ID, "ui-accordiontab-1")

    # Management - Facility Configuration > Access Plam > New Access Plan > Dropdowns > Checkboxes
    def get_selected_checkboxes_for_table_xpath(self, table):
        locator = (By.XPATH, "(//*[@id='ui-accordiontab-" + str(
            table - 1) + "-content']/div/p-table/div/div/table/tbody/tr/td/p-checkbox/div/div/span)[contains(@class,'pi-check')]")
        return locator

    def get_locator_for_table_checkboxes_by_table_column_and_row(self, table, column, row):
        elements = "(//*[@id='ui-accordiontab-" + str(table - 1) + \
                   "-content']/div/p-table/div/div/table/tbody/tr/td[" + str(column) + "]/p-checkbox/div/div/span)"

        if (str(row)) != "*":
            elements = elements + "[" + str(row) + "]"

        locator = (By.XPATH, elements)
        return locator

    # Management - Facility Configuration > Fire alarm > Submenus
    alarm_configuration_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Alarm Configuration'))
    alarm_message_submenu_xpath = (By.XPATH, getMenuLocatorXpath('Alarm Message'))

    # Management - Common Buttons
    ok_button_xpath = (By.XPATH, getSpanButtonLocatorXpath('OK'))
    yes_button_xpath = (By.XPATH, getSpanButtonLocatorXpath('Yes'))
    no_button_xpath = (By.XPATH, getSpanButtonLocatorXpath('No'))
    save_button_xpath = (By.XPATH, getMenuButtonLocatorXpath('Save'))






