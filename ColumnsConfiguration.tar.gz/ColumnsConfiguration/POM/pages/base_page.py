from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys, ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, ElementNotInteractableException
from selenium.webdriver.support.wait import WebDriverWait


class BasePage:

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(self.driver, 10)

    def open_page(self):
        self.driver.get(self.base_url)
        sleep(1)

    def get_element(self, locator):
        try:
            element_present = EC.presence_of_element_located(locator)
            return self.wait.until(element_present)
        except TimeoutException:
            raise TimeoutException(
                "TimeoutException: Element not found on page, used selector: By." + locator[0] + "(\"" + locator[
                    1] + "\")")

    def get_elements(self, locator):
        return self.driver.find_elements(*locator)

    def click_elements(self, locator):
        elements = self.get_elements(locator)
        for element in elements:
            element.click()
            # ActionChains(self.driver).move_to_element(element).click(element).perform()

    def get_title(self):
        return self.driver.title

    def click(self, locator):
        try:
            element_present = EC.presence_of_element_located(locator)
            self.wait.until(element_present).click()
        except TimeoutException:
            raise TimeoutException("TimeoutException: Element not found on page, used selector: By." + locator[0] + "(\"" + locator[1] + "\")")
        except ElementNotInteractableException:
            try:
                element_present = EC.presence_of_element_located(locator)
                element = self.wait.until(element_present)
                ActionChains(self.driver).move_to_element(element).click(element).perform()
            except ElementNotInteractableException:
                raise ElementNotInteractableException("ElementNotInteractableException: Element is not interactable, used selector: By." + locator[0] + "(\"" + locator[1] + "\")")

    def send_keys(self, locator, text):
        try:
            element_present = EC.presence_of_element_located(locator)
            self.wait.until(element_present).send_keys(Keys.CONTROL + "a" + Keys.DELETE)
            self.wait.until(element_present).send_keys(text)

        except TimeoutException:
            raise TimeoutException("TimeoutException: Element not found on page, used selector: By." + locator[0] + "(\"" + locator[1] + "\")")


