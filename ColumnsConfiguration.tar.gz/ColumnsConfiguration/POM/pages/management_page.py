import os
from POM.pages.base_page import *
from POM.locators.management_page_locators import ManagementPageLocators
from POM.helpers import ConfReader


class ManagementPage(ManagementPageLocators, BasePage):
    configurations = os.path.join(os.path.abspath(os.path.dirname(os.path.dirname(__file__) + "/../tests/")), 'dev_env.env')
    ip_address = ConfReader.get_value(configurations, 'ENTRY_IP_ADDRESS')
    base_url = "http://" + ip_address + ":8888/"

    def enter_username(self, username):
        self.send_keys(self.username_textbox_name, username)

    def enter_password(self, password):
        self.send_keys(self.password_textbox_name, password)

    def enter_plan_name(self, name):
        self.send_keys(self.access_plan_name_textbox_xpath, name)

    def click_login_button(self):
        self.click(self.login_button_xpath)

    def click_ok_button(self):
        self.click(self.ok_button_xpath)

    def click_yes_button(self):
        element = self.get_element(self.yes_button_xpath)
        ActionChains(self.driver).move_to_element(element).click(element).perform()

    def click_no_button(self):
        self.click(self.no_button_xpath)

    def get_active_devices_table_exit_row(self):
        return self.get_element(self.active_devices_table_exit_row_xpath)

    def get_active_devices_table_entry_row(self):
        return self.get_element(self.active_devices_table_entry_row_xpath)

    def click_system_configuration_menu(self):
        self.click(self.system_configuration_menu_xpath)

    def click_access_plans_submenu(self):
        self.click(self.access_plans_submenu_xpath)

    def click_system_services_submenu(self):
        self.click(self.system_services_submenu_xpath)

    def click_update_nodelist_from_meshnodes(self):
        self.click(self.system_update_nodelist_from_meshnodes_button_xpath)

    def click_facility_configuration_menu(self):
        self.click(self.facility_configuration_menu_xpath)

    def click_zones_submenu(self):
        self.click(self.zones_submenu_xpath)

    def click_lane_entry_edit_button(self):
        self.click(self.lane_entry_edit_button_xpath)

    def click_lane_exit_edit_button(self):
        self.click(self.lane_exit_edit_button_xpath)

    def click_zone_from_dropdown_button(self):
        self.click(self.zone_from_dropdown_button_xpath)

    def click_zone_to_dropdown_button(self):
        self.click(self.zone_to_dropdown_button_xpath)

    def click_zone_from_dropdown_button(self):
        self.click(self.zone_from_dropdown_button_xpath)

    def click_zone_to_dropdown_button(self):
        self.click(self.zone_to_dropdown_button_xpath)

    def click_dropdown_option_outside(self):
        self.click(self.dropdown_option_outside_xpath)

    def click_dropdown_option_shorttermzone(self):
        self.click(self.dropdown_option_shorttermzone_xpath)

    def click_dropdown_option_contractzone(self):
        self.click(self.dropdown_option_contractzone_xpath)

    def click_save_button(self):
        self.click(self.save_button_xpath)

    def click_new_access_plan_button(self):
        self.click(self.new_access_plan_button_xpath)

    def click_entry_access_plan_details_dropdown(self):
        self.click(self.entry_access_plan_details_dropdown_id)

    def click_exit_access_plan_details_dropdown(self):
        self.click(self.exit_access_plan_details_dropdown_id)

    def click_lane_devices_submenu(self):
        self.click(self.lane_devices_submenu_xpath)

    def select_default_checkboxes(self):
        self.click_entry_access_plan_details_dropdown()
        self.click_elements(self.get_locator_for_table_checkboxes_by_table_column_and_row(1, 2, "*"))
        self.click_elements(self.get_locator_for_table_checkboxes_by_table_column_and_row(1, 3, 2))
        self.click_entry_access_plan_details_dropdown()
        sleep(2)
        self.click_exit_access_plan_details_dropdown()
        self.click_elements(self.get_locator_for_table_checkboxes_by_table_column_and_row(2, 2, "*"))
        self.click_elements(self.get_locator_for_table_checkboxes_by_table_column_and_row(2, 3, 2))
        self.click_exit_access_plan_details_dropdown()

    def unselect_selected_checkboxes(self):
        self.click_entry_access_plan_details_dropdown()
        self.click_elements(self.get_selected_checkboxes_for_table_xpath(1))
        self.click_entry_access_plan_details_dropdown()

        self.click_exit_access_plan_details_dropdown()
        self.click_elements(self.get_selected_checkboxes_for_table_xpath(2))
        self.click_exit_access_plan_details_dropdown()

    def click_lane_devices_submenu(self):
        self.click(self.lane_devices_submenu_xpath)

    def click_entry_device_td_text(self):
        self.click(self.entry_device_td_text_xpath)

    def click_exit_device_td_text(self):
        self.click(self.exit_device_td_text_xpath)

    def click_edit_node_button(self):
        self.click(self.edit_node_button_xpath)

    def click_button_enabled_checkbox(self):
        element = self.get_element(self.button_enabled_checkbox_xpath)
        ActionChains(self.driver).move_to_element(element).click(element).perform()

    def click_enable_lpr_checkbox(self):
        element = self.get_element(self.enable_lpr_checkbox_xpath)
        ActionChains(self.driver).move_to_element(element).click(element).perform()

    def click_reader_enabled_checkbox(self):
        element = self.get_element(self.reader_enabled_checkbox_xpath)
        ActionChains(self.driver).move_to_element(element).click(element).perform()

    def enter_camera_user(self, username):
        locator = self.camera_user_textbox_xpath
        element = self.get_element(locator)
        ActionChains(self.driver).move_to_element(element).perform()
        self.send_keys(locator, username)

    def enter_camera_password(self, password):
        camera_pw_locator = self.camera_password_textbox_xpath
        camera_pw_element = self.get_element(camera_pw_locator)
        ActionChains(self.driver).move_to_element(camera_pw_element).perform()
        self.send_keys(camera_pw_locator, password)

        camera_pw_ver_locator = self.camera_password_verification_textbox_xpath
        camera_pw_ver_element = self.get_element(camera_pw_ver_locator)
        ActionChains(self.driver).move_to_element(camera_pw_ver_element).perform()
        self.send_keys(camera_pw_ver_locator, password)

    def enter_node_friendly_name(self, name):
        locator = self.friendly_name_textbox_xpath
        element = self.get_element(locator)
        ActionChains(self.driver).move_to_element(element).perform()
        self.send_keys(locator, name)

    def enter_node_display_url(self, url):
        locator = self.display_url_textbox_xpath
        element = self.get_element(locator)
        ActionChains(self.driver).move_to_element(element).perform()
        self.send_keys(locator, url)
