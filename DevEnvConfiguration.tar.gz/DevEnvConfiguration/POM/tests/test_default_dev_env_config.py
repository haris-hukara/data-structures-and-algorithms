import sys, os
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__) + "/../../")))
from time import sleep
from POM.config_tests import *
from POM.pages.dev_env_page import DevEnvPage
from POM.pages.management_page import ManagementPage
from POM.helpers import ConfReader


class TestDefaultDevEnvConfig(ConfigTests):

    configurations = os.path.join(os.path.dirname(__file__), 'dev_env.env')
    LOGIN_USERNAME = ConfReader.get_value(configurations, 'LOGIN_USERNAME')
    LOGIN_PASSWORD = ConfReader.get_value(configurations, 'LOGIN_PASSWORD')
    ACCESS_PLAN_NAME = ConfReader.get_value(configurations, 'ACCESS_PLAN_NAME')
    ENTRY_COLUMN_FRIENDLY_NAME = ConfReader.get_value(configurations, 'ENTRY_COLUMN_FRIENDLY_NAME')
    EXIT_COLUMN_FRIENDLY_NAME = ConfReader.get_value(configurations, 'EXIT_COLUMN_FRIENDLY_NAME')
    CAMERA_USERNAME = ConfReader.get_value(configurations, 'CAMERA_USERNAME')
    CAMERA_PASSWORD = ConfReader.get_value(configurations, 'CAMERA_PASSWORD')

    @classmethod
    def setUpClass(cls):
        cls.driver = super().init_driver(cls)
        cls.managementPage = ManagementPage(cls.driver)
        cls.devEnvPage = DevEnvPage(cls.driver)

    def test_000_dev_env_screen_ip_check(self):
        devEnvPage = self.devEnvPage
        devEnvPage.open_page()
        title = devEnvPage.get_heading_text()
        assert title == "Development Environment Essential"
        # "TestDefaultDevEnvConfig.entryScreenIp" is received from dev env page localhost:8200
        #  It is used in test steps 008 and 009, where we configure entry/exit node friendly name, display url, etc.
        TestDefaultDevEnvConfig.entryScreenIp = str(devEnvPage.get_entry_screen_src())
        TestDefaultDevEnvConfig.exitScreenIp = str(devEnvPage.get_exit_screen_src())

    def test_001_page_title(self):
        managementPage = self.managementPage
        managementPage.open_page()
        title = managementPage.get_title()
        assert title == "essential Management Center"

    def test_002_login(self):
        managementPage = self.managementPage
        managementPage.enter_username(self.LOGIN_USERNAME)
        managementPage.enter_password(self.LOGIN_PASSWORD)
        managementPage.click_login_button()
        assert managementPage.get_active_devices_table_exit_row()
        assert managementPage.get_active_devices_table_entry_row()
        managementPage.click_ok_button()

    def test_003_update_nodelist(self):
        managementPage = self.managementPage
        managementPage.click_system_configuration_menu()
        managementPage.click_system_services_submenu()
        managementPage.click_update_nodelist_from_meshnodes()

    def test_004_facility_configuration_zones(self):
        managementPage = self.managementPage
        managementPage.click_facility_configuration_menu()
        managementPage.click_zones_submenu()

    def test_005_zones_lane_entry(self):
        managementPage = self.managementPage
        managementPage.click_lane_entry_edit_button()
        managementPage.click_yes_button()
        managementPage.click_zone_from_dropdown_button()
        managementPage.click_dropdown_option_outside()
        managementPage.click_zone_to_dropdown_button()
        managementPage.click_dropdown_option_shorttermzone()
        managementPage.click_save_button()

    def test_006_zones_lane_exit(self):
        managementPage = self.managementPage
        managementPage.click_lane_exit_edit_button()
        managementPage.click_yes_button()
        managementPage.click_zone_from_dropdown_button()
        managementPage.click_dropdown_option_shorttermzone()
        managementPage.click_zone_to_dropdown_button()
        managementPage.click_dropdown_option_outside()
        managementPage.click_save_button()

    def test_007_create_access_plan(self):
        managementPage = self.managementPage
        managementPage.click_access_plans_submenu()
        managementPage.click_new_access_plan_button()
        managementPage.enter_plan_name(self.ACCESS_PLAN_NAME)
        managementPage.select_default_checkboxes()
        managementPage.click_save_button()

    def test_008_entry_device_configuration(self):
        managementPage = self.managementPage
        managementPage.click_lane_devices_submenu()
        managementPage.click_entry_device_td_text()
        managementPage.click_edit_node_button()
        managementPage.enter_node_friendly_name(self.ENTRY_COLUMN_FRIENDLY_NAME)
        # You can put http address of entry node as a string instead of "TestDefaultDevEnvConfig.entryScreenIp"
        managementPage.enter_node_display_url(TestDefaultDevEnvConfig.entryScreenIp)
        managementPage.click_button_enabled_checkbox()
        managementPage.click_enable_lpr_checkbox()
        managementPage.enter_camera_user(self.CAMERA_USERNAME)
        managementPage.enter_camera_password(self.CAMERA_PASSWORD)
        managementPage.click_save_button()

    def test_009_exit_device_configuration(self):
        managementPage = self.managementPage
        managementPage.click_exit_device_td_text()
        managementPage.click_edit_node_button()
        managementPage.enter_node_friendly_name(self.EXIT_COLUMN_FRIENDLY_NAME)
        # You can put http address of exit node as a string instead of "TestDefaultDevEnvConfig.entryScreenIp"
        managementPage.enter_node_display_url(TestDefaultDevEnvConfig.exitScreenIp)
        managementPage.click_reader_enabled_checkbox()
        managementPage.click_save_button()

    @classmethod
    def tearDownClass(cls):
        super().driver_quit(cls)


if __name__ == '__main__':
    unittest.main()
