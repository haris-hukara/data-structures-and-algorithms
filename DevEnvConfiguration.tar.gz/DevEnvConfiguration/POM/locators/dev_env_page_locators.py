from selenium.webdriver.common.by import By


def getDevEnvButtonXpath(div_id, name):
    return "//div[@id='" + div_id + "']/button[text()='" + name + "']"


class DevEnvPageLocators:
    page_heading_tag_name = (By.TAG_NAME, "h3")

    entry_screen_img_xpath = (By.XPATH, "//div[@id='screen']//img")
    exit_screen_img_xpath = (By.XPATH, "//div[@id='screen2']//img")
