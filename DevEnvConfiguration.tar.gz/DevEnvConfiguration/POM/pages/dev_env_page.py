import os
from POM.pages.base_page import *
from POM.locators.dev_env_page_locators import DevEnvPageLocators
from POM.helpers import ConfReader


class DevEnvPage(DevEnvPageLocators, BasePage):
    configurations = os.path.join(os.path.abspath(os.path.dirname(os.path.dirname(__file__) + "/../tests/")), 'dev_env.env')
    ip_address = ConfReader.get_value(configurations, 'IP_ADDRESS')
    base_url = "http://" + ip_address + ":8200/"

    def get_heading_text(self):
        element = self.get_element(self.page_heading_tag_name)
        return element.text

    def get_entry_screen_src(self):
        element = self.get_element(self.entry_screen_img_xpath)
        return element.get_attribute("src")

    def get_exit_screen_src(self):
        element = self.get_element(self.exit_screen_img_xpath)
        return element.get_attribute("src")
